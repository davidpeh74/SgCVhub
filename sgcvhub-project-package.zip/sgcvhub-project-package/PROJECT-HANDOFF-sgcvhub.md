# Project Handoff — Singapore Commercial Vehicle Hub (sgcvhub.com)

A running summary of everything decided and built so far, so work can continue in a new chat. Paste this in to bring the next session up to speed.

---

## 1. The Business (confirmed facts)

- **Name:** Singapore Commercial Vehicle Hub (sgcvhub.com), aka SgCVhub.
- **What it is:** An **authorised reseller** for three commercial vehicle brands — **Foton, Mitsubishi Fuso, Opel**.
- **Started:** January 2026. **One unit sold to date** (genuinely new — do not imply a long track record).
- **Showroom:** 8 Tuas Ave 18, Singapore 638892.
- **Contact:** Email ask@sgcvhub.com · WhatsApp/phone 8822 5335.
- **Social:** Facebook, Instagram, LinkedIn.
- **Market:** Singapore only. Serves SMEs through MNCs.

### Services
- Three brands compared in one place (incl. all-electric Opel **Combo-e** and **Vivaro-e**, Foton **eMR**, Fuso **eCanter**).
- Custom body building via **workshop partners**: refrigerated/chiller, box, canopy, tipper, checkered plate, crane/lorry crane, custom interior racking.
- Financing and insurance.
- Trade-in and scrapping.

### Core positioning / USPs
- Only site to compare all three brands in one place, **no obligation**.
- **Lead mechanism:** visitor submits company name, contact person, email, phone → receives a **detailed brochure** that goes beyond the website.
- Guidance on which brand/model fits the business (not just a catalogue).
- EV option none of the competitors lead with.
- One contact for vehicle + body build + financing + trade-in.

### What the website is NOT (guardrails for all copy/design)
- Not a single-brand dealership pitch.
- Not high-pressure or salesy (no countdown timers, no aggressive pop-ups).
- Not a faceless corporate fleet portal — warm, approachable, local.
- Not overstating track record (new business, be honest).
- Not a plain spec dump — match vehicle to the job.

### Brand personality
Warm, approachable, helpful, straightforward.

---

## 2. Sitemap (flat navigation — "Option A")

**Primary nav (6 links + CTA button):**
Home `/` · Brands `/brands` · Customisation `/customisation` · About `/about` · Blog `/blog` · Contact `/contact` · **[Get Brochure]** `/brochure` (distinct button)

**Footer:**
- Site: Home, Brands, Customisation, About, Contact
- Resources: Blog, Request Brochure, Newsletter signup (inline)
- Legal: Privacy Policy `/privacy`, Terms of Service `/terms`
- Repeats contact details + social icons.

**Utility pages:** Thank You `/thank-you`, 404 `/404`.

**URL convention:** flat, lowercase, hyphenated. No nested paths. No dropdowns.

**Key IA decisions:**
- Brochure request is its own page + persistent header button (primary conversion, not buried in Contact).
- Customisation kept separate from Brands (different buyer questions; it's a differentiator).
- Contact stays in main nav (local showroom = trust).
- Privacy Policy lives in footer + linked from the brochure form.

**Conversion paths:**
- Lead capture (primary): "Get Your Brochure" → `/brochure` form → `/thank-you`.
- Self-qualify: "Compare the Brands" → `/brands`; "See Customisation Options" → `/customisation`.
- Newsletter: footer + Blog + opt-in on thank-you.
- Trust: "How we work" → `/about`, showroom block on `/contact`.

---

## 3. Chosen Design Direction: "Option 5 — On-Brand Light"

Light/airy theme using the corporate colours, leaning into the warm/approachable personality. (Option 4 was the dark alternative; rejected in favour of light.)

### Logo (existing — kept, not redesigned)
- White-and-green **"SgCVhub" wordmark** ("Sg" + "hub" white, "CV" green) on deep teal.
- **Must sit on a dark surface** (deep teal header bar + footer). Never on white/pale — white letters vanish.
- Wordmark only; no standalone symbol. Favicon uses the wordmark as-is (no new symbol introduced).
- User explored new logo directions but decided to **keep the existing logo**.

### Colour tokens
| Role | Name | Hex |
|---|---|---|
| Primary | Deep Teal | `#0F3741` |
| Accent | Leaf Green | `#39BA2E` |
| Accent (small text/links, AA) | Forest Green | `#2F9E26` |
| Accent muted (numbered labels) | — | `#6CAB64` |
| Background | White | `#FFFFFF` |
| Surface tint (alt sections) | Mist | `#F1F6F3` |
| Card surface | Pale Sage | `#F4F9F6` |
| Border | Sage Line | `#E0ECE6` |
| Border hover | Sage Mid | `#C7DBD2` |
| Body text | Slate Teal | `#45565A` |
| Muted text | Grey Teal | `#7D8C8A` |
| Text on dark | Soft Teal | `#A9C2C4` |
| Button label (on green) | Near-black | `#08251C` |
| Success `#2F9E26` · Warning `#C8841C` · Error `#C73B2E` · Info `#2B7A8C` | | |

**Contrast rule:** use `#2F9E26` (not `#39BA2E`) for small green text on white. Green buttons use `#08251C` label.

### Typography (Google Fonts)
- **Headings:** Outfit (600/700/800).
- **Body:** Work Sans (400/500/600/700).
- Scale: Display clamp(48–80px)/800 · H1 44px/800 · H2 34px/700 · H3 24px/700 · H4 18px/600 · Body large 18px · Body 16px · Body small 13px. Body line-height 1.6.

### Other tokens
- **Spacing:** 8px grid (4,8,12,16,24,32,48,64,96,128).
- **Radius:** sm 6 · md 8 (buttons) · lg 14 (cards) · xl 20 (CTA cards/modals) · pill 999.
- **Shadows:** elev-1 `0 1px 3px rgba(15,55,65,.06)` · elev-2 `0 4px 12px rgba(15,55,65,.08)` · elev-3 `0 10px 28px rgba(15,55,65,.12)` · elev-cta `0 6px 18px rgba(57,186,46,.30)`.
- **Breakpoints:** mobile <640 · tablet 640–1024 · desktop ≥1024 · large ≥1280 (content max-width 1140px).
- **Icons:** Lucide, outline, 1.8px stroke, rounded. Avoid handshake/globe/gear/dollar-bag clichés.
- **Motion:** buttons lift 2px, cards 3px, 150ms ease. No page transitions. Respect prefers-reduced-motion.
- **Components avoided/used sparingly:** modals only for confirmations (brand is no-pressure); skeletons over spinners.

### Paste-ready CSS :root
```css
:root{
  --primary:#0F3741; --accent:#39BA2E; --accent-text:#2F9E26; --accent-muted:#6CAB64;
  --bg:#FFFFFF; --mist:#F1F6F3; --card:#F4F9F6; --border:#E0ECE6; --border-hover:#C7DBD2;
  --text:#45565A; --muted:#7D8C8A; --on-dark:#A9C2C4; --btn-label:#08251C;
  --success:#2F9E26; --warning:#C8841C; --error:#C73B2E; --info:#2B7A8C;
  --font-head:'Outfit',sans-serif; --font-body:'Work Sans',sans-serif;
  --space-1:4px;--space-2:8px;--space-3:12px;--space-4:16px;--space-5:24px;
  --space-6:32px;--space-7:48px;--space-8:64px;--space-9:96px;--space-10:128px;
  --radius-sm:6px;--radius-md:8px;--radius-lg:14px;--radius-xl:20px;--radius-pill:999px;
  --elev-1:0 1px 3px rgba(15,55,65,0.06); --elev-2:0 4px 12px rgba(15,55,65,0.08);
  --elev-3:0 10px 28px rgba(15,55,65,0.12); --elev-cta:0 6px 18px rgba(57,186,46,0.30);
}
```

### Imagery
- **Primary hero:** the three-vehicle line-up (Foton eMR, Fuso eCanter, Opel Combo) — shows all three brands at once.
- Secondary: workshop/customisation shots. Accent: EV (Combo-e/eMR with charging cue).
- Clean, bright, full colour. Real vehicles/people, never stock-corporate handshakes. Green as light accent only.

---

## 4. Page Copy Status (5 pages written)

Finished, paste-ready copy exists for: **Home, Brands, Customisation, Get Brochure, About.** Each has one hero angle, SEO meta title + description, and section-by-section copy following brand guardrails (no em dashes, no hype, no "we believe").

**Still needs the owner's real facts** (marked as REPLACE in the copy doc):
- A real customer testimonial (15–50 words + name/role/business type).
- Confirmed model lists + key specs for each brand (Foton, Fuso, Opel).
- Confirmation of the Brands comparison table rows.
- Founder/team background for About (optional but helps).
- Showroom opening hours.

**Hero angles chosen:** Home = specificity · Brands = benefit · Customisation = outcome · Get Brochure = proof-of-value · About = contrarian.

**Pages not yet written:** Blog, Contact, Privacy, Terms, Thank You, 404.

---

## 5. Open Items / Next Steps

1. Fill in the REPLACE facts above (especially per-brand model specs and a testimonial).
2. Export a logo variant: keep white logo on dark teal bars, OR a transparent/dark-text version if ever needed on light. (Decision so far: keep white logo on dark bars only.)
3. Confirm Opel Combo-e / Vivaro-e are formally available for sale in SG under the reseller arrangement before leading hard on the EV claim.
4. Write remaining pages (Contact is quick once hours are confirmed; Privacy/Terms best done with proper legal wording).
5. Build the actual pages — start with the homepage — using the design tokens above and the written copy.

---

## 6. Files produced so far
- `brief-v2-sgcvhub.md` — sharpened brief.
- `sitemap-sgcvhub.md` — flat-nav sitemap (Option A).
- `design-options-sgcvhub.html` — 5 rendered design directions.
- `brand-guide-sgcvhub.md` — Option 5 brand guide (narrative).
- `brand-sgcvhub.md` + `brand-sgcvhub.html` — final structured spec + visual style guide (with embedded logo + hero).
- `page-outlines-and-copy-sgcvhub.docx` — outlines + paste-ready copy for 5 pages.
- `PROJECT-HANDOFF-sgcvhub.md` — this file.
